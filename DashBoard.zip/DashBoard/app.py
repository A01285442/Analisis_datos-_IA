import streamlit as st
from components.sidebar import create_dimex_sidebar, render_dimex_modals
# Importa tus páginas
import P_vendedores
import P_sucursales
import P_dashboard
import P_estadistica
import P_asistenteAI



# -----------------------------
# Sidebar con navegación
# -----------------------------
def sidebar():
    st.sidebar.title("DIMEX Dashboard")

    menu = st.sidebar.radio(
        "Navegación",
        [
            "Dashboard",
            "Estadística",
            "Vendedores",
            "Sucursales",
            "Asistente IA",
        ]
    )

    return menu


# -----------------------------
# Router: carga la página seleccionada
# -----------------------------
def router(page):
    if page == "Dashboard":
        P_dashboard.render()
    elif page == "Estadística":
        P_estadistica.render()
    elif page == "Vendedores":
        P_vendedores.render()
    elif page == "Sucursales":
        P_sucursales.render()
    elif page == "Asistente IA":
        P_asistenteAI.render()

    else:
        st.error("Página no encontrada")


# -----------------------------
# MAIN APP
# -----------------------------
def main():
    st.set_page_config(page_title="DIMEX", layout="wide")

    page = sidebar()
    router(page)


# Ejecutar app
if __name__ == "__main__":
    main()
