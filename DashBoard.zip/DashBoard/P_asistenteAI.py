import streamlit as st
import pandas as pd
from google import genai
from google.genai import types
from dotenv import load_dotenv
import numpy as np
import os

# Componentes DIMEX
from utils.theme import get_theme_colors
from utils.css_manager import apply_css
from components.header import create_page_header
from utils.icons import get_icon

# =============================================================================
# RENDER PRINCIPAL DE LA PÁGINA (INTEGRADO AL ROUTER)
# =============================================================================
def render():

    # --------------------------- CONFIG DE PÁGINA -----------------------------
    st.set_page_config(
        page_title="Asistente IA - Gemini", 
        page_icon="🤖",
        layout="wide"
    )

    HAS_RERUN = hasattr(st, "rerun")

    # -------------------------- INICIALIZAR GEMINI ---------------------------
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")

    try:
        if not api_key:
            st.error("Error: No se encontró GEMINI_API_KEY.")
            st.stop()
        client = genai.Client(api_key=api_key) 
    except Exception as e:
        st.error(f"Error al inicializar Gemini: {e}")
        st.stop()

    # ------------------------- ROLES DEL ASISTENTE ---------------------------
    ROLES_DEFINITIONS = """
Eres un asistente inteligente de DIMEX que adopta diferentes roles según la consulta:

[Rol: Riesgo] → Análisis de cartera, deterioro, IMOR, alertas.  
[Rol: Cobranza] → Estrategias, priorización, seguimientos.  
[Rol: Servicio] → Procesos, productos, información general.  
[Rol: Fraude] → Anomalías, validación sospechosa, patrones extraños.

INSTRUCCIONES:
1. Detecta automáticamente el rol apropiado.
2. Indica el rol al inicio de la respuesta.
3. Explica de forma profesional y concisa.
4. Si faltan datos, solicita detalles específicos.
"""

    # ======================================================================
    # FUNCIONES DE EXTRACCIÓN / FILTRO (SIN CAMBIOS, SOLO LIGERA LIMPIEZA)
    # ======================================================================

    def generate_data_summary(df):
        summary_parts = []
        summary_parts.append(f"Total de registros: {len(df)}")

        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if any(k in col.lower() for k in ["saldo", "capital"]):
                summary_parts.append(
                    f"{col}: Total=${df[col].sum():,.0f}, "
                    f"Promedio=${df[col].mean():,.0f}, "
                    f"Máximo=${df[col].max():,.0f}"
                )
        return "\n".join(summary_parts)

    def extract_relevant_data(df, query, max_rows=20):
        if df is None or df.empty:
            return "No hay datos disponibles."

        query_lower = query.lower()
        relevant_cols = []

        keyword_mapping = {
            'saldo': ['Saldo Insoluto Actual', 'SaldoInsolutoActual', 'Saldo_Actual'],
            'vencido': ['Saldo Insoluto Vencido', 'SaldoInsolutoVencidoActual', 'Saldo_Vencido'],
            'sucursal': ['Sucursal', 'Region', 'Región'],
            'vendedor': ['Vendedor', 'Nombre Vendedor'],
            'capital': ['Capital Dispersado', 'CapitalDispersadoActual','CapitalLiquidadoActual'],
            'castigo': ['Castigos', 'CastigosActual'],
            'fpd': ['%FPD', 'FPD', 'FPDActual'],
            'imor': ['IMOR', 'Porcentaje_Vencido'],
            '3089': ['3089', 'Saldo30-89'],
        }

        for keyword, cols in keyword_mapping.items():
            if keyword in query_lower:
                relevant_cols += [c for c in cols if c in df.columns]

        id_cols = ['Sucursal', 'Vendedor', 'Región', 'Region']
        relevant_cols += [c for c in id_cols if c in df.columns and c not in relevant_cols]

        if not relevant_cols:
            important = ['Sucursal', 'Saldo Insoluto Actual', 'SaldoInsolutoActual', 'Saldo_Actual', 'Vendedor']
            relevant_cols = [c for c in important if c in df.columns]

        try:
            df_filtered = df[relevant_cols].copy()
        except:
            df_filtered = df.copy()

        saldo_cols = [c for c in df_filtered.columns if 'saldo' in c.lower() and 'actual' in c.lower()]
        if saldo_cols:
            df_filtered = df_filtered.sort_values(saldo_cols[0], ascending=False)

        df_filtered = df_filtered.head(max_rows)
        summary = generate_data_summary(df_filtered)

        return f"""
RESUMEN ESTADÍSTICO:
{summary}

DATOS (Top {len(df_filtered)}):
{df_filtered.to_markdown(index=False, floatfmt=".2f")}
"""

    def detect_intent_and_filter(query, df):
        q = query.lower()

        if any(w in q for w in ['top', 'mayor', 'más alto']):
            for col in ['Saldo Insoluto Actual', 'SaldoInsolutoActual', 'Saldo_Actual']:
                if col in df.columns:
                    return df.nlargest(10, col)

        if any(w in q for w in ['bajo', 'menor', 'peor']):
            for col in ['Saldo Insoluto Actual', 'SaldoInsolutoActual', 'Saldo_Actual']:
                if col in df.columns:
                    return df.nsmallest(10, col)

        if any(w in q for w in ['riesgo', 'vencido', 'deterioro']):
            if 'Saldo_Vencido' in df.columns and 'Saldo_Actual' in df.columns:
                df2 = df.copy()
                df2['IMOR'] = df2['Saldo_Vencido'] / df2['Saldo_Actual']
                return df2.nlargest(15, 'IMOR')

        return df

    def generate_response(prompt, context):
        full_prompt = f"""
{ROLES_DEFINITIONS}

CONTEXTO DE DATOS:
{context}

PREGUNTA: {prompt}

Responde de manera clara y profesional.
"""

        try:
            result = client.models.generate_content(
                model='gemini-2.0-flash',
                contents=full_prompt,
                config=types.GenerateContentConfig(
                    temperature=0.7,
                    max_output_tokens=2048,
                )
            )
            return result.text
        except Exception as e:
            return f"❌ ERROR: {e}"

    # ======================================================================
    # CARGA DE DATOS
    # ======================================================================
    @st.cache_data
    def load_excel_data(path='Base_Con_NA_Historico.csv'):
        try:
            if path.endswith(('.xlsx', '.xls')):
                return pd.read_excel(path)
            elif path.endswith('.csv'):
                for enc in ['utf-8', 'latin-1', 'ISO-8859-1', 'cp1252']:
                    try:
                        return pd.read_csv(path, encoding=enc)
                    except:
                        pass
                raise ValueError("No encoding compatible")
            else:
                raise ValueError("Formato no soportado")
        except Exception as e:
            st.error(f"⚠️ {e}")
            return None

    # ======================================================================
    # UI DIMEX
    # ======================================================================
    apply_css("assistant")

    create_page_header(
        "🤖 Asistente Inteligente DIMEX",
        "Consulta especializada con selección automática de rol experto"
    )

    colors = get_theme_colors()

    # ------------------- Cargar Datos -------------------
    if "df" not in st.session_state:
        st.session_state["df"] = None

    with st.expander("⚙️ Configuración de datos", expanded=False):
        archivo = st.text_input("Archivo:", "Base_Con_NA_Historico.csv")
        if st.button("🔁 Cargar archivo"):
            with st.spinner("Cargando..."):
                df_loaded = load_excel_data(archivo)
                if df_loaded is not None:
                    st.session_state["df"] = df_loaded
                    st.success(f"✅ {len(df_loaded)} registros")
                    if HAS_RERUN:
                        st.rerun()

    st.markdown("---")

    # ======================================================================
    # CHAT
    # ======================================================================

    if "messages" not in st.session_state:
        st.session_state["messages"] = [
            {
                "role": "assistant",
                "content": """¡Hola! 👋 Soy tu asistente inteligente DIMEX.

Puedo ayudarte con:
- 📊 Riesgo  
- 💰 Cobranza  
- 📋 Servicio  
- 🔍 Fraude  

Solo escribe tu consulta."""
            }
        ]

    for msg in st.session_state["messages"]:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    if prompt := st.chat_input("💭 Escribe tu consulta..."):

        if st.session_state["df"] is None:
            st.error("⚠️ Primero carga un archivo.")
            st.stop()

        st.session_state["messages"].append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        with st.spinner("Analizando y extrayendo datos relevantes..."):
            df = st.session_state["df"]
            df_filtered = detect_intent_and_filter(prompt, df)
            context = extract_relevant_data(df_filtered, prompt)
            response = generate_response(prompt, context)

        with st.chat_message("assistant"):
            st.markdown(response)

        st.session_state["messages"].append({"role": "assistant", "content": response})

    st.markdown("---")
    st.caption(f"💬 Mensajes: {len(st.session_state['messages'])} | 🤖 Rol automático activo")
