"""
TEMPLATE REUTILIZABLE PARA NUEVOS MÓDULOS DIMEX
================================================
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ============================================================
# CONFIGURACIÓN DE PÁGINA
# ============================================================
st.set_page_config(
    page_title="Nombre del Módulo",
    page_icon="📊",
    layout="wide"
)

# ¿Tu versión tiene st.rerun?
HAS_RERUN = hasattr(st, "rerun")

# ============================================================
# SISTEMA DE TEMAS
# ============================================================

def get_theme_colors():
    if "theme" not in st.session_state:
        st.session_state["theme"] = "dark"

    if st.session_state["theme"] == "dark":
        return {
            'bg_primary': '#0f1116',
            'bg_secondary': '#1a1d24',
            'bg_card': '#1e293b',
            'text_primary': '#e2e8f0',
            'text_secondary': '#cbd5e0',
            'text_muted': '#94a3b8',
            'border': '#2d3748',
            'accent': "#63AB32",
            'accent_secondary': '#2FEB00',
            'success': '#22c55e',
            'warning': '#eab308',
            'error': '#ef4444',
            'grid': '#334155',
        }
    else:
        return {
            'bg_primary': '#ffffff',
            'bg_secondary': '#f8fafc',
            'bg_card': '#ffffff',
            'text_primary': '#1e293b',
            'text_secondary': '#475569',
            'text_muted': '#64748b',
            'border': '#e2e8f0',
            'accent': "#63AB32",
            'accent_secondary': '#2FEB00',
            'success': '#16a34a',
            'warning': '#ca8a04',
            'error': '#dc2626',
            'grid': '#e2e8f0'
        }

# ====== ESTADO GLOBAL ======
if "show_config_modal" not in st.session_state:
    st.session_state["show_config_modal"] = False

if "show_user_modal" not in st.session_state:
    st.session_state["show_user_modal"] = False

# NUEVO: estado para notificaciones
if "show_notifications_modal" not in st.session_state:
    st.session_state["show_notifications_modal"] = False

# Datos de usuario por defecto
if "user_name" not in st.session_state:
    st.session_state["user_name"] = "Usuario DIMEX"

if "user_email" not in st.session_state:
    st.session_state["user_email"] = "usuario@dimex.com"

if "user_password" not in st.session_state:
    st.session_state["user_password"] = "********"

# ============================================================
# CSS DINÁMICO
# ============================================================

def apply_custom_css():
    colors = get_theme_colors()

    st.markdown(
        f"""
        <style>
        [data-testid="stAppViewContainer"] {{
            background-color: {colors['bg_primary']} !important;
        }}
        .main, .block-container {{
            background-color: {colors['bg_primary']} !important;
            color: {colors['text_primary']} !important;
        }}
        h1,h2,h3,h4,h5,h6,p,span,label {{
            color: {colors['text_primary']} !important;
        }}
        [data-testid="stSidebar"] {{
            background: linear-gradient(180deg, {colors['accent']} 0%, {colors['accent_secondary']} 100%);
        }}
        .dimex-sidebar-card * {{
            color: {colors['text_primary']} !important;
        }}
        .section-title {{
            color: {colors['text_primary']};
            font-size: 1.6rem;
            font-weight: 700;
            padding-bottom: 10px;
            border-bottom: 3px solid {colors['accent']};
            margin-bottom: 20px;
        }}
        .metric-card {{
            background: {colors['bg_card']};
            border-left: 5px solid {colors['accent']};
            border-radius: 12px;
            padding: 1rem;
            box-shadow: 0 3px 10px rgba(0,0,0,0.25);
        }}
        .alert-box {{
            background: {colors['bg_card']};
            border-radius: 10px;
            padding: 1rem;
            border: 1px solid {colors['border']};
        }}
        /* Botones generales: texto blanco siempre */
        .stButton > button {{
            background: linear-gradient(135deg, {colors['accent']} 0%, {colors['accent_secondary']} 100%) !important;
            color: white !important;
            border: none !important;
            border-radius: 8px !important;
            padding: 0.5rem 1.5rem !important;
            font-weight: 600 !important;
            cursor: pointer;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

# ============================================================
# SIDEBAR
# ============================================================

def create_dimex_sidebar():
    colors = get_theme_colors()

    with st.sidebar:

        # LOGO
        st.markdown(f"""
        <div class="dimex-sidebar-card" style="text-align:center;
             padding:1rem; background:{colors['bg_card']}; border-radius:12px; margin-bottom:1rem;">
            <h1 style="color:{colors['accent']}">DIMEX</h1>
            <p style="color:{colors['text_muted']}">Sistema Predictivo</p>
            <hr style="border-color:{colors['border']}">
            <p style="color:{colors['text_secondary']}; font-size:0.8rem;">Tu Módulo v1.0</p>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("### 📚 Navegación")
        st.markdown(f"""
        <div class="dimex-sidebar-card" style="padding:1rem; background:{colors['bg_card']}; border-radius:12px;">
            <ul style="padding-left:1.2rem; line-height:1.8;">
                <li>Home</li>
                <li>Dashboard</li>
                <li>Estadísticas</li>
                <li>Asistente IA</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")

        # INFO DE DATOS
        if "df" in st.session_state:
            df = st.session_state["df"]
            st.markdown("### 📊 Datos cargados")
            st.markdown(f"""
            <div class="dimex-sidebar-card" style="padding:1rem; background:{colors['bg_card']}; border-radius:12px;">
                <p><b>Registros:</b> {df.shape[0]:,}</p>
                <p><b>Columnas:</b> {df.shape[1]}</p>
                <p><b>Nulos:</b> {df.isnull().sum().sum():,}</p>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("---")

        st.markdown("### 📚 Recursos")
        st.markdown(f"""
        <div class="dimex-sidebar-card" style="padding:1rem; background:{colors['bg_card']}; border-radius:12px;">
            <ul style="padding-left:1.2rem; line-height:1.8;">
                <li><a href="#" style="color:{colors['accent']}">📖 Documentación</a></li>
                <li><a href="#" style="color:{colors['accent']}">💬 Soporte</a></li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")

        # NUEVO: BOTÓN NOTIFICACIONES
        if st.button("🔔 Notificaciones", use_container_width=True):
            st.session_state["show_notifications_modal"] = True
            st.session_state["show_user_modal"] = False
            st.session_state["show_config_modal"] = False
            if HAS_RERUN:
                st.rerun()

        # BOTÓN USUARIO
        if st.button("👤 Usuario", use_container_width=True):
            st.session_state["show_user_modal"] = True
            st.session_state["show_config_modal"] = False
            st.session_state["show_notifications_modal"] = False
            if HAS_RERUN:
                st.rerun()

        # BOTÓN CONFIGURACIÓN ABAJO
        if st.button("⚙️ Configuración", use_container_width=True):
            st.session_state["show_config_modal"] = True
            st.session_state["show_user_modal"] = False
            st.session_state["show_notifications_modal"] = False
            if HAS_RERUN:
                st.rerun()

# ============================================================
# CABECERA
# ============================================================

def create_page_header(title, subtitle):
    colors = get_theme_colors()

    st.markdown(f"""
        <div style="
            background: linear-gradient(120deg, {colors['accent']} 70%, {colors['accent_secondary']} 100%);
            padding: 1.5rem; border-radius: 12px; color: white; margin-bottom: 1.5rem;
        ">
            <h1>{title}</h1>
            <p style="margin-top:-5px; opacity:0.9;">{subtitle}</p>
        </div>
    """, unsafe_allow_html=True)

# ============================================================
# CARGA DE DATOS
# ============================================================

@st.cache_data
def load_excel_data(file_path):
    try:
        if file_path.endswith((".xlsx", ".xls")):
            return pd.read_excel(file_path)
        elif file_path.endswith(".csv"):
            return pd.read_csv(file_path, encoding="latin-1")
        else:
            st.error("Formato no válido. Usa CSV o Excel.")
            st.stop()
    except Exception as e:
        st.error(f"Error al cargar archivo: {e}")
        st.stop()

# ============================================================
# FIGURAS PLOTLY
# ============================================================

def create_plotly_figure(**kwargs):
    colors = get_theme_colors()
    template = "plotly_dark" if st.session_state["theme"] == "dark" else "plotly_white"

    fig = go.Figure()
    fig.update_layout(
        template=template,
        paper_bgcolor=colors['bg_primary'],
        plot_bgcolor=colors['bg_card'],
        font=dict(color=colors['text_primary']),
        **kwargs
    )
    return fig

# ============================================================
# TARJETAS
# ============================================================

def create_metric_card(label, value, extra=None):
    return f"""
        <div class="metric-card">
            <div style="font-size:0.9rem; opacity:0.8;">{label}</div>
            <div style="font-size:1.6rem; font-weight:700;">{value}</div>
            {"<div style='font-size:0.8rem; opacity:0.7;'>" + extra + "</div>" if extra else ""}
        </div>
    """

# ============================================================
# FUNCIONES PARA NOTIFICACIONES (reuso de P_Estadistica)
# ============================================================

def _safe_ratio(numerador, denominador):
    num = pd.to_numeric(numerador, errors='coerce')
    den = pd.to_numeric(denominador, errors='coerce')
    return np.where((den == 0) | (pd.isna(den)) | (pd.isna(num)), np.nan, num / den)

def _create_target_for_notifications(df_notif: pd.DataFrame):
    """
    Replica la lógica de P_Estadistica para construir Deterioro_Crediticio.
    Devuelve una Serie con 0/1 (y NaN si no se pudo calcular).
    """
    df = df_notif.copy()

    # Variables de ingeniería (solo si existen las columnas base)
    if 'SaldoInsolutoVencidoActual' in df.columns and 'SaldoInsolutoActual' in df.columns:
        df['ICV'] = _safe_ratio(df['SaldoInsolutoVencidoActual'], df['SaldoInsolutoActual'])

    if 'CapitalLiquidadoActual' in df.columns and 'CapitalDispersadoActual' in df.columns:
        df['Ratio_Recuperacion'] = _safe_ratio(df['CapitalLiquidadoActual'], df['CapitalDispersadoActual'])

    if 'QuitasActual' in df.columns and 'CastigosActual' in df.columns and 'SaldoInsolutoActual' in df.columns:
        df['Perdidas_Total'] = df['QuitasActual'].fillna(0) + df['CastigosActual'].fillna(0)
        df['Ratio_Perdidas'] = _safe_ratio(df['Perdidas_Total'], df['SaldoInsolutoActual'])

    if '%FPDActual' in df.columns:
        df['FPD_Actual'] = pd.to_numeric(df['%FPDActual'], errors='coerce')

    # Columna 30-89
    col_3089 = None
    for col in df.columns:
        if '3089' in str(col) and 'Actual' in str(col):
            col_3089 = col
            break
    if col_3089 and 'SaldoInsolutoActual' in df.columns:
        df['Ratio_30_89'] = _safe_ratio(df[col_3089], df['SaldoInsolutoActual'])

    # Definir target igual que en P_Estadistica
    def create_target(df_):
        cond1 = (df_['ICV'] > 0.05) if 'ICV' in df_.columns else pd.Series([False] * len(df_))
        cond2 = (df_['Ratio_30_89'] > 0.03) if 'Ratio_30_89' in df_.columns else pd.Series([False] * len(df_))
        cond3 = (df_['FPD_Actual'] > 0.06) if 'FPD_Actual' in df_.columns else pd.Series([False] * len(df_))
        target_arr = (cond1 & cond2 & cond3).astype(float)  # 1.0 / 0.0
        return pd.Series(target_arr.values, index=df_.index)

    try:
        target_series = create_target(df)
        return target_series
    except Exception:
        return pd.Series([np.nan] * len(df_notif), index=df_notif.index)

def get_risk_counts_for_notifications(df: pd.DataFrame):
    """
    Devuelve conteos y porcentajes para Rojo / Amarillo / Verde.
    Rojo: Deterioro_Crediticio = 1
    Verde: Deterioro_Crediticio = 0
    Amarillo: NaN (si hubiera).
    """
    total = len(df)
    if total == 0:
        return {
            "rojo": (0, 0.0),
            "amarillo": (0, 0.0),
            "verde": (0, 0.0),
            "total": 0
        }

    # Si ya existe Deterioro_Crediticio lo usamos directo
    if 'Deterioro_Crediticio' in df.columns:
        target = pd.to_numeric(df['Deterioro_Crediticio'], errors='coerce')
    else:
        # Lo reconstruimos a partir de las columnas base
        target = _create_target_for_notifications(df)

    rojo_mask = target == 1
    verde_mask = target == 0
    amarillo_mask = target.isna()

    rojo = int(rojo_mask.sum())
    verde = int(verde_mask.sum())
    amarillo = int(amarillo_mask.sum())

    def pct(x):
        return float(x) * 100.0 / total if total > 0 else 0.0

    return {
        "rojo": (rojo, pct(rojo)),
        "amarillo": (amarillo, pct(amarillo)),
        "verde": (verde, pct(verde)),
        "total": total
    }

# ============================================================
# APLICAR CSS Y SIDEBAR
# ============================================================

apply_custom_css()
create_dimex_sidebar()

# ============================================================
# CARGAR DATOS (una sola vez)
# ============================================================

if "df" not in st.session_state:
    st.session_state["df"] = load_excel_data("Base_de_datos_Dimex.csv")

df = st.session_state["df"]

# ============================================================
# PANTALLA NOTIFICACIONES
# ============================================================

if st.session_state.get("show_notifications_modal", False):
    colors = get_theme_colors()
    stats = get_risk_counts_for_notifications(df)

    (rojo_count, rojo_pct) = stats["rojo"]
    (amarillo_count, amarillo_pct) = stats["amarillo"]
    (verde_count, verde_pct) = stats["verde"]
    total = stats["total"]

    st.markdown("<br>", unsafe_allow_html=True)
    col_left, col_center, col_right = st.columns([1, 2, 1])

    with col_center:
        # Tarjeta título
        st.markdown(f"""
        <div style="
            background:{colors['bg_card']};
            border-radius:12px;
            border:1px solid {colors['border']};
            padding:1.5rem 2rem;
            box-shadow:0 8px 24px rgba(0,0,0,0.4);
            margin-bottom:1.5rem;
            text-align:center;
        ">
            <h2 style="margin-top:0; color:{colors['text_primary']};">
                🔔 Centro de Notificaciones
            </h2>
            <p style="margin:0; color:{colors['text_secondary']}; font-size:0.95rem;">
                Resumen de sucursales en riesgo y niveles de salud del portafolio, basado
                en la información cargada.
            </p>
        </div>
        """, unsafe_allow_html=True)

        # Card Rojo
        st.markdown(f"""
        <div style="
            background:{colors['bg_card']};
            border-radius:10px;
            border-left:5px solid {colors['error']};
            padding:0.9rem 1.2rem;
            margin-bottom:0.8rem;
            color:{colors['text_primary']};
        ">
            <strong>🔴 Sucursales en riesgo (Rojo):</strong>
            {rojo_count} sucursal(es), equivalentes al {rojo_pct:.1f}% del portafolio.
        </div>
        """, unsafe_allow_html=True)

        # Card Amarillo
        st.markdown(f"""
        <div style="
            background:{colors['bg_card']};
            border-radius:10px;
            border-left:5px solid {colors['warning']};
            padding:0.9rem 1.2rem;
            margin-bottom:0.8rem;
            color:{colors['text_primary']};
        ">
            <strong>🟡 Sucursales en observación (Amarillo):</strong>
            {amarillo_count} sucursal(es), equivalentes al {amarillo_pct:.1f}% del portafolio.
        </div>
        """, unsafe_allow_html=True)

        # Card Verde
        st.markdown(f"""
        <div style="
            background:{colors['bg_card']};
            border-radius:10px;
            border-left:5px solid {colors['success']};
            padding:0.9rem 1.2rem;
            margin-bottom:0.8rem;
            color:{colors['text_primary']};
        ">
            <strong>🟢 Sucursales sanas (Verde):</strong>
            {verde_count} sucursal(es), equivalentes al {verde_pct:.1f}% del portafolio.
        </div>
        """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        if st.button("Cerrar notificaciones", use_container_width=True):
            st.session_state["show_notifications_modal"] = False
            if HAS_RERUN:
                st.rerun()

    st.stop()

# ============================================================
# PANTALLA USUARIO
# ============================================================

if st.session_state["show_user_modal"]:
    colors = get_theme_colors()

    st.markdown("<br>", unsafe_allow_html=True)
    col_left, col_center, col_right = st.columns([1, 2, 1])

    with col_center:
        # Tarjeta título
        st.markdown(f"""
        <div style="
            background:{colors['bg_card']};
            border-radius:12px;
            border:1px solid {colors['border']};
            padding:1.5rem 2rem;
            box-shadow:0 8px 24px rgba(0,0,0,0.4);
            margin-bottom:1.5rem;
            text-align:center;
        ">
            <h2 style="margin-top:0; color:{colors['text_primary']};">
                👤 Perfil de Usuario
            </h2>
        </div>
        """, unsafe_allow_html=True)

        # Avatar + datos
        avatar_col, form_col = st.columns([1, 2])

        with avatar_col:
            st.markdown(f"""
            <div style="
                display:flex;
                justify-content:center;
                align-items:center;
                margin-top:0.5rem;
            ">
                <div style="
                    width:110px;
                    height:110px;
                    border-radius:50%;
                    background:{colors['bg_secondary']};
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    box-shadow:0 4px 15px rgba(0,0,0,0.4);
                    font-size:3rem;
                ">
                    👤
                </div>
            </div>
            """, unsafe_allow_html=True)
            # Debajo de la foto mostramos nombre y correo actuales
            st.markdown(
                f"<p style='text-align:center; margin-top:0.6rem; font-weight:600;'>{st.session_state['user_name']}</p>"
                f"<p style='text-align:center; margin-top:-0.4rem; font-size:0.85rem; color:{colors['text_muted']};'>{st.session_state['user_email']}</p>",
                unsafe_allow_html=True
            )

        with form_col:
            st.markdown("### Datos de la cuenta")

            st.text_input("Nombre", key="user_name")
            st.text_input("Correo electrónico", key="user_email")
            st.text_input("Contraseña", key="user_password", type="password")

            if st.button("Guardar cambios", use_container_width=True):
                st.success("Datos de usuario actualizados.")

            st.markdown("<br>", unsafe_allow_html=True)

            if st.button("Cerrar usuario", use_container_width=True):
                st.session_state["show_user_modal"] = False
                if HAS_RERUN:
                    st.rerun()

    st.stop()

# ============================================================
# PANTALLA CONFIGURACIÓN
# ============================================================

if st.session_state["show_config_modal"]:
    colors = get_theme_colors()

    st.markdown("<br>", unsafe_allow_html=True)
    col_left, col_center, col_right = st.columns([1, 2, 1])

    with col_center:
        st.markdown(f"""
        <div style="
            background:{colors['bg_card']};
            border-radius:12px;
            border:1px solid {colors['border']};
            padding:1.5rem 2rem;
            box-shadow:0 8px 24px rgba(0,0,0,0.4);
            margin-bottom:1.5rem;
            text-align:center;
        ">
            <h2 style="margin-top:0; color:{colors['text_primary']};">
                ⚙️ Configuración del Sistema
            </h2>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("### Tema de color")
        st.write("Selecciona el tema:")

        theme_option = st.radio(
            "Tema:",
            ["Oscuro", "Claro"],
            index=0 if st.session_state["theme"] == "dark" else 1,
            horizontal=True,
            label_visibility="collapsed"
        )

        new_theme = "dark" if theme_option == "Oscuro" else "light"
        if st.session_state["theme"] != new_theme:
            st.session_state["theme"] = new_theme
            if HAS_RERUN:
                st.rerun()

        st.markdown("<br>", unsafe_allow_html=True)

        if st.button("Cerrar configuración", use_container_width=True):
            st.session_state["show_config_modal"] = False
            if HAS_RERUN:
                st.rerun()

    # NO dibujar nada más mientras está abierta la configuración
    st.stop()

# ============================================================
# A PARTIR DE AQUÍ SOLO SE MUESTRA CUANDO NO ESTÁ ABIERTA NINGUNA PANTALLA
# ============================================================

create_page_header("Título del Módulo", "Descripción breve del módulo")

# ============================================================
# SECCIÓN KPIs
# ============================================================

st.markdown('<div class="section-title">📊 Métricas Principales</div>', unsafe_allow_html=True)

c1, c2, c3, c4 = st.columns(4)

with c1:
    st.markdown(create_metric_card("Total Registros", f"{df.shape[0]:,}", "✓ Actualizado"), unsafe_allow_html=True)
with c2:
    st.markdown(create_metric_card("Columnas", df.shape[1], f"{df.shape[1]} variables"), unsafe_allow_html=True)
with c3:
    nulos = df.isnull().sum().sum()
    st.markdown(create_metric_card("Valores Nulos", nulos, f"{(nulos/df.size*100):.2f}%"), unsafe_allow_html=True)
with c4:
    mem = df.memory_usage(deep=True).sum() / 1024**2
    st.markdown(create_metric_card("Memoria Utilizada", f"{mem:.2f} MB", "✓ Optimizado"), unsafe_allow_html=True)

st.markdown("---")

# ============================================================
# SECCIÓN VISUALIZACIONES
# ============================================================

st.markdown('<div class="section-title">📈 Análisis Visual</div>', unsafe_allow_html=True)

tabs = st.tabs(["📊 Tab 1", "📈 Tab 2", "🔍 Tab 3"])

with tabs[0]:
    st.write("### Ejemplo de gráfico")
    fig = create_plotly_figure(height=350)
    fig.add_trace(go.Bar(
        x=["A", "B", "C", "D"],
        y=[10, 25, 15, 30],
        marker_color=get_theme_colors()["accent"],
        text=[10, 25, 15, 30],
        textposition="outside"
    ))
    st.plotly_chart(fig, use_container_width=True)

with tabs[1]:
    st.write("### Contenido del Tab 2")
with tabs[2]:
    st.write("### Contenido del Tab 3")

st.markdown("---")

# ============================================================
# TABLAS DE DATOS
# ============================================================

st.markdown('<div class="section-title">📋 Exploración de Datos</div>', unsafe_allow_html=True)

with st.expander("Ver primeras 20 filas"):
    st.dataframe(df.head(20), use_container_width=True, height=380)

with st.expander("Estadísticas descriptivas"):
    st.dataframe(df.describe(), use_container_width=True)

st.markdown("---")

# ============================================================
# ALERTAS
# ============================================================

c1, c2 = st.columns(2)

with c1:
    st.markdown(f"""
    <div class="alert-box" style="border-left:5px solid {get_theme_colors()['success']}">
        <h4>✅ Estado del sistema</h4>
        Todo funciona correctamente.
    </div>""", unsafe_allow_html=True)

with c2:
    st.markdown(f"""
    <div class="alert-box" style="border-left:5px solid #4299e1">
        <h4>ℹ️ Información</h4>
        Los datos se actualizan cada hora automáticamente.
    </div>""", unsafe_allow_html=True)

st.markdown("---")

# ============================================================
# FOOTER
# ============================================================

colors = get_theme_colors()
st.markdown(f"""
<div style="text-align:center; padding:2rem; border-top:1px solid {colors['border']}; opacity:0.7;">
    <p><b>Sistema DIMEX v1.0</b></p>
    <p style='font-size:0.85rem;'>Desarrollado con Streamlit & Plotly</p>
</div>
""", unsafe_allow_html=True)
